package com.saeed.wifitesting;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private WifiManager wifi;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        wifi = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        root = new LinearLayout(this); root.setOrientation(1);
        root.setPadding(dp(18), dp(22), dp(18), dp(18));
        root.setBackgroundColor(0xFFF4F7FB);
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Saeed WiFi Testing"); title.setTextSize(25); title.setTextColor(0xFF0D47A1);
        title.setGravity(Gravity.CENTER); title.setPadding(0,0,0,dp(8)); root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Wi-Fi information & safe home-network checks");
        sub.setTextSize(14); sub.setGravity(Gravity.CENTER); sub.setTextColor(0xFF455A64);
        root.addView(sub);

        status = new TextView(this); status.setTextSize(15); status.setTextColor(0xFF263238);
        status.setPadding(dp(12),dp(14),dp(12),dp(14)); status.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(18); root.addView(status,sp);

        addButton("Refresh Wi-Fi Details", v -> showWifi());
        addButton("Open Wi-Fi Settings", v -> startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        addButton("Open Router Admin Page", v -> openRouter());
        addButton("Check Password Strength", v -> passwordCheck());
        addButton("Internet Connection Test", v -> internetCheck());
        TextView note = new TextView(this);
        note.setText("\nSafety note: Use router settings and network checks only on networks you own or have permission to manage. This app does not crack passwords, generate WPS PINs, or attempt unauthorized access.");
        note.setTextSize(12); note.setTextColor(0xFF546E7A); root.addView(note);
        showWifi();
    }

    private void addButton(String text, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(10);
        root.addView(b,p); b.setOnClickListener(listener);
    }

    private void showWifi() {
        StringBuilder s = new StringBuilder();
        try {
            if (!wifi.isWifiEnabled()) {
                s.append("Wi-Fi is OFF. Turn it on in Wi-Fi Settings.");
            } else {
                WifiInfo i = wifi.getConnectionInfo();
                String ssid = i.getSSID();
                if (ssid == null || ssid.equals("<unknown ssid>")) ssid = "Unavailable (grant location permission / enable Location)";
                s.append("Connected Wi-Fi: ").append(ssid)
                 .append("\nSignal: ").append(i.getRssi()).append(" dBm")
                 .append("\nLink speed: ").append(i.getLinkSpeed()).append(" Mbps")
                 .append("\nFrequency: ").append(i.getFrequency()).append(" MHz")
                 .append("\nIP address: ").append(ip(i.getIpAddress()))
                 .append("\nGateway: ").append(gateway());
            }
        } catch (Exception e) { s.append("Could not read Wi-Fi details: ").append(e.getMessage()); }
        status.setText(s.toString());
    }

    private String ip(int n) {
        return (n & 255)+"."+((n >> 8)&255)+"."+((n >> 16)&255)+"."+((n >> 24)&255);
    }
    private String gateway() {
        try {
            int g = wifi.getDhcpInfo().gateway;
            return ip(g);
        } catch(Exception e) { return "Unavailable"; }
    }
    private void openRouter() {
        String g = gateway();
        if (g.equals("Unavailable") || g.equals("0.0.0.0")) {
            Toast.makeText(this,"Connect to your home Wi-Fi first",Toast.LENGTH_LONG).show(); return;
        }
        Intent in = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("http://" + g));
        startActivity(Intent.createChooser(in,"Open router page"));
    }
    private void passwordCheck() {
        EditText e = new EditText(this); e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setHint("Enter a sample password (not your real one)");
        new android.app.AlertDialog.Builder(this).setTitle("Password Strength").setView(e)
          .setPositiveButton("Check",(d,w)->{
            String p=e.getText().toString(); int score=0;
            if(p.length()>=12) score++; if(p.matches(".*[a-z].*")) score++;
            if(p.matches(".*[A-Z].*")) score++; if(p.matches(".*[0-9].*")) score++;
            if(p.matches(".*[^A-Za-z0-9].*")) score++;
            String r = score<=2 ? "Weak — use a longer unique passphrase." :
                      score<=3 ? "Fair — add length and variety." : "Stronger — keep it unique.";
            new android.app.AlertDialog.Builder(this).setTitle("Result").setMessage(r+"\nNever reuse passwords.").setPositiveButton("OK",null).show();
          }).setNegativeButton("Cancel",null).show();
    }
    private void internetCheck() {
        status.setText("Checking internet connection...");
        new Thread(() -> {
            boolean ok=false;
            try { ok = InetAddress.getByName("connectivitycheck.gstatic.com").isReachable(2500); } catch(Exception ignored) {}
            final boolean result=ok;
            runOnUiThread(() -> status.setText(result ? "Internet host reachable." : "No response received. This basic check may be blocked by the network."));
        }).start();
    }
}
