# Saeed WiFi Testing (Android source project)

This is a starter Android Studio project for Android 6.0+ (tested target intended for Android 13).
Included:
- Connected Wi-Fi SSID (when Android privacy permissions allow it), RSSI, link speed, frequency, IP and gateway
- Shortcut to Android Wi-Fi settings
- Opens the local router gateway page
- Local password-strength estimate (use a sample, not your real password)
- Basic internet reachability check

Not included: password cracking, default-password keygen, WPS PIN generation, unauthorized device discovery or attack tooling.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Allow Gradle sync and install Android SDK Platform 35.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

For Android 13, grant Location permission if Android requests it and enable Location services to display the Wi-Fi SSID. Android may restrict some Wi-Fi details depending on OS version and device settings.
